package com.example.davaleban5.fragments

import android.support.v4.app.Fragment
import com.example.davaleban5.R

class SecondFragment: Fragment(R.layout.fragment_second) {
}