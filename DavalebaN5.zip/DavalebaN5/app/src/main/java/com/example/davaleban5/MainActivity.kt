package com.example.davaleban5

import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var editText: EditText
    private lateinit var addBtn: Button
    private lateinit var clearBtn: Button
    private lateinit var textView: TextView

    private lateinit var sharedPreferences: SharedPreferences


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText = findViewById(R.id.editText)
        addBtn = findViewById(R.id.addBtn)
        clearBtn = findViewById(R.id.clearBtn)
        textView = findViewById(R.id.textView)
        sharedPreferences=getSharedPreferences("MY_PREFERENCES", MODE_PRIVATE)
        val prefNote = sharedPreferences.getString("NOTE","")
        textView.text = prefNote


        addBtn.setOnClickListener{
            val note= editText.text.toString()

            if (note.isNullOrEmpty()){
                return@setOnClickListener
            }

            val notes=textView.text.toString()
            val resultText=notes + "\n" + note
            textView.text = resultText
            editText.setText("")

            sharedPreferences.edit()
                .putString("NOTE",resultText)
                .apply()

        }

        clearBtn.setOnClickListener{
            textView.text = ""
            sharedPreferences.edit()
                .putString("NOTE","")
                .apply()
        }
    }
}