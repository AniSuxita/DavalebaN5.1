package com.example.davaleban5.fragments

import com.example.davaleban5.R

class FirstFragment: Fragment(R.layout.fragment_first) {
}